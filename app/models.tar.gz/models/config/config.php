<?php

sfConfig::set(sf_root_cache_dir, '/test');

?>