<?php

class Competitor extends AppModel
{
	var $name = 'Competitor';
   	var $useTable = false;
}    
?>