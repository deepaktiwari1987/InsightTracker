<?php

class calculatorsConfiguration extends sfApplicationConfiguration
{
  public function configure()
  {
  }
}
