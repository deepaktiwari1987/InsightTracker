<?php 
echo $sf_content ?>