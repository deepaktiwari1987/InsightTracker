<?php

class Customer extends AppModel
{
	var $name = 'Insight';
   	var $useTable = false;
}    
?>