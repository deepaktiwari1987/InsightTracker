<?php

class Insight extends AppModel
{
	var $name = 'Insight';
	
	function getInsightData($arrFields=array(),$arrConditions=array())
	{
		return $this->find('first',array('fields'=>$arrFields,'conditions'=>$arrConditions));
	}

	/**
	* Returns pilotgroup id on the basis of insight id.
	*/
	function getCreatedById($insightId) {
		$result = $this->find('first',array('fields'=>array('user_id'),'conditions'=> array('Insight.id' => $insightId)));	
		return $result['Insight']['user_id'];
	}   

}    

?>