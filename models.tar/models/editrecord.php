<?php

class Editrecord extends AppModel
{
	var $name = 'Editrecord ';
  var $useTable = false;
}  

?>