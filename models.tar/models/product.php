<?php

class Product extends AppModel
{
	var $name = 'Product';
   	var $useTable = false;
}    
?>